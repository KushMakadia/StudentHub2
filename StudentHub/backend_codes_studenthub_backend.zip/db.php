<?php
if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'studenthub');
}

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $conn->connect_error]));
}

$conn->set_charset('utf8mb4');

function log_audit($conn, $student_id, $action, $details) {
    $stmt = $conn->prepare("INSERT INTO audit_logs (student_id, action, details) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $student_id, $action, $details);
    $stmt->execute();
    $stmt->close();
}
?>