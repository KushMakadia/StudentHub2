<?php
require_once 'db.php';
require_once 'auth_check.php';
checkAdminRole();

$student_count = $conn->query("SELECT COUNT(*) AS count FROM students WHERE role = 'student'")->fetch_assoc()['count'];
$event_count   = $conn->query("SELECT COUNT(*) AS count FROM events")->fetch_assoc()['count'];
$reg_count     = $conn->query("SELECT COUNT(*) AS count FROM registrations")->fetch_assoc()['count'];

$latest_regs = $conn->query(
    "SELECT r.id, s.name AS student_name, e.title AS event_title, r.registered_at 
     FROM registrations r
     JOIN students s ON r.student_id = s.student_id
     JOIN events e ON r.event_id = e.id
     ORDER BY r.registered_at DESC LIMIT 5"
);

$logs = $conn->query("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 10");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?> (Admin)</h2>
        <nav>
            <a href="Admin.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <main>
        <section class="stats-cards">
            <div class="card">Total Students: <strong><?php echo $student_count; ?></strong></div>
            <div class="card">Active Events: <strong><?php echo $event_count; ?></strong></div>
            <div class="card">Total Registrations: <strong><?php echo $reg_count; ?></strong></div>
        </section>

        <section>
            <h3>Recent System Audit Logs</h3>
            <table border="1" cellpadding="6">
                <tr><th>ID</th><th>User ID</th><th>Action</th><th>Details</th><th>Timestamp</th></tr>
                <?php while ($log = $logs->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $log['id']; ?></td>
                    <td><?php echo $log['student_id'] ?? 'System'; ?></td>
                    <td><?php echo htmlspecialchars($log['action']); ?></td>
                    <td><?php echo htmlspecialchars($log['details']); ?></td>
                    <td><?php echo $log['created_at']; ?></td>
                </tr>
                <?php endwhile; ?>
            </table>
        </section>
    </main>
</body>
</html>
