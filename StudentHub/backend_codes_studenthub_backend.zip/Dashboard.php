<?php
require_once 'auth_check.php';
require_once 'db.php';
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h2>Welcome, <?php echo htmlspecialchars($user_name); ?>!</h2>
        <nav>
            <a href="Dashboard.php">Dashboard</a>
            <a href="Events.html">View Events</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>
    <main>
        <section class="card">
            <h3>Your Student Portal</h3>
            <p>Email: <?php echo htmlspecialchars($_SESSION['email']); ?></p>
            <p>Role: <?php echo htmlspecialchars($_SESSION['role']); ?></p>
        </section>
    </main>
</body>
</html>
